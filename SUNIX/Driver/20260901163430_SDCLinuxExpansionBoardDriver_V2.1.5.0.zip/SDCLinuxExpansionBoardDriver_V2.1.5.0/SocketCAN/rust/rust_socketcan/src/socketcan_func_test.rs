/**
 * @file socketcan_func_test.rs
 * @brief cmd list for test SocketCAN function
 * 
 * Copyright (C) 2026, SUNIX Co., Ltd.
 *
 * Authors      : Max Chang <max.chang@sunix.com>
 * 
 * 
**/

use std::fs;
use std::io;
use std::thread;
use std::sync::atomic::{AtomicBool, Ordering};
use socketcan::Socket;
use socketcan::SocketOptions;
use socketcan::{CanFdSocket, CanSocket, EmbeddedFrame, CanFrame, CanFdFrame, CanAnyFrame,Id, StandardId, ExtendedId, CanFilter};
use std::sync::Mutex;
use std::sync::Arc;
use std::time::Duration;

pub static OPENED_DEVICES: Mutex<Option<String>> = Mutex::new(None);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CanType {
    Classic,
    Fd,    
}

pub enum CanSocketKind {
    Classic(CanSocket),
    Fd(CanFdSocket),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CanIdType {
    Standard, // 11-bit
    Extended, // 29-bit
}

pub fn get_can_type_by_mtu(name: &str) -> CanType {

    let sys_path = format!("/sys/class/net/{}/mtu", name);
    
    if let Ok(mtu_str) = fs::read_to_string(sys_path) {
        if let Ok(mtu_val) = mtu_str.trim().parse::<u32>() {

            if mtu_val == 72 {
                return CanType::Fd;
            }
        }
    }
    
    CanType::Classic
}

pub struct SocketCanDevice {
    pub socket: CanSocketKind,
    pub name: String,
    pub can_type: CanType,
}

fn check_device_open() -> Result<(), io::Error> {
    let opened = OPENED_DEVICES.lock().unwrap();
    
    if let Some(ref name) = *opened {
        println!("========================================");
        println!("#WARN: Some net device is opened, is {}", name);
        println!("========================================");
        return Err(io::Error::new(
            io::ErrorKind::AlreadyExists,
            format!("#WARN: Device {} is already open", name),
        ));
    }
    Ok(())
}

pub fn socketcan_open() -> Result<SocketCanDevice, io::Error> {

    let name = crate::utils::input_can_net_device_name()?;

    check_device_open()?;

    let can_type: CanType = get_can_type_by_mtu(&name);

    let socket_kind = match can_type {
        CanType::Fd => {
            let fd_socket = CanFdSocket::open(&name)?;
            fd_socket.set_nonblocking(true)?;
            CanSocketKind::Fd(fd_socket)
        }
        _ => {
            let classic_socket = CanSocket::open(&name)?;
            classic_socket.set_nonblocking(true)?;
            CanSocketKind::Classic(classic_socket)
        }
    };

    let mut opened = OPENED_DEVICES.lock().unwrap();
    *opened = Some(name.clone());

    println!("#INFO: CAN Channel: {}, CAN Type: {:?}", name, can_type);
    Ok(SocketCanDevice {
        socket: socket_kind,
        name,
        can_type,
    })
}


pub fn start_can_receiver(device: &SocketCanDevice)
{
    let running = Arc::new(AtomicBool::new(true));
    let running_clone = running.clone();

    println!("Starting CAN receiver thread for {}...", device.name);
    println!("Press 'Q'|'q' to stop receiving and return to menu.\n");

    let socket_ptr = device as *const SocketCanDevice;

    let socket_ptr_safe = unsafe { &*socket_ptr };

    let handle = thread::spawn(move || {
        while running_clone.load(Ordering::SeqCst) {
            let res = match &socket_ptr_safe.socket {
                CanSocketKind::Fd(s) => s.read_frame(),
                CanSocketKind::Classic(s) => {
                    match s.read_frame() {
                        Ok(frame) => std::convert::TryInto::try_into(frame).map_err(|_| {
                            std::io::Error::new(std::io::ErrorKind::Other, "Convert frame error")
                        }),
                        Err(e) => Err(e),
                    }
                }
            };

            match res {
                Ok(frame) => match frame {
                    CanAnyFrame::Normal(f) => {
                        println!("Received CAN 2.0 Frame: ID={:X?}, DLC={}, Length={},Data={:X?}", f.id(), f.dlc(), f.data().len(),f.data());
                    }
                    CanAnyFrame::Fd(f) => {
                        
                        let is_brs = f.is_brs();
                        let is_esi = f.is_esi();

                        println!("Received CAN FD Frame: ID={:X?}, BRS={}, ESI={}, DLC={}, Length={}, Data={:X?}", f.id(), if is_brs { "1 (Active)" } else { "0 (Inactive)" }, if is_esi { "1 (Error Passive)" } else { "0 (Error Active)" }, f.dlc(), f.data().len(),f.data());
                    }
                    CanAnyFrame::Remote(f) => {
                        println!("Received Remote Frame: ID={:X?}, DLC={}", f.id(), f.dlc());
                    }
                    _ => {}
                },
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                    thread::sleep(Duration::from_millis(10));
                }
                Err(e) => {
                    eprintln!("Error reading CAN frame: {}", e);
                    break;
                }
            }
        }
        println!("CAN receiver thread exiting clean.");
    });
    
    let term = console::Term::stdout();
    
    loop {
  
        match term.read_char() {
            Ok('\u{1b}') => { 
                println!("\n[ESC] pressed. Stopping receiver...");
                running.store(false, Ordering::SeqCst);
                break;
            }
            Ok('\u{3}') | Ok('q') | Ok('Q') => {
                println!("\nExit signal pressed. Stopping receiver...");
                running.store(false, Ordering::SeqCst);
                break;
            }
            Ok(_) => {
                
            }
            Err(e) => {
                eprintln!("Error reading key: {:?}", e);
                running.store(false, Ordering::SeqCst);
                break;
            }
        }
    }

    if let Err(e) = handle.join() {
        eprintln!("Thread panicked: {:?}", e);
    }
}

impl SocketCanDevice {
    pub fn write_data_can(&self, can_id: u32, id_type: CanIdType, data: &[u8]) -> Result<(), io::Error> {
        
        if self.can_type == CanType::Fd {
            println!("#INFO: Current device is in CAN FD mode. Skipping write_data_can.");
            return Ok(());
        }

        if data.len() > crate::utils::CAN_MAX_DLEN {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "#ERROR: CAN 2.0 data length cannot exceed 8 bytes",
            ));
        }
                            
        let id = match id_type {
            CanIdType::Standard => {

                let std_id = StandardId::new(can_id as u16).ok_or_else(|| {
                    io::Error::new(io::ErrorKind::InvalidInput, "#ERROR: Invalid 11-bit CAN ID (Max: 0x7FF)")
                })?;
                Id::Standard(std_id)
            }
            CanIdType::Extended => {

                let ext_id = ExtendedId::new(can_id).ok_or_else(|| {
                    io::Error::new(io::ErrorKind::InvalidInput, "#ERROR: Invalid 29-bit Extended CAN ID (Max: 0x1FFFFFFF)")
                })?;
                Id::Extended(ext_id)
            }
        };

        let frame = CanFrame::new(id, data).ok_or_else(|| {
            io::Error::new(io::ErrorKind::Other, "Failed to create CAN 2.0 frame")
        })?;
        
        match &self.socket {
            CanSocketKind::Classic(classic_socket) => {
                classic_socket.write_frame(&frame)?;                
            }
            _ => {}
        }
        
        println!("📤 [CAN 2.0] Sent ok -> ID: 0x{:X}, Data: {:X?}", can_id, data);

        Ok(())
    }

    pub fn write_data_can_fd(&self, can_id: u32, id_type: CanIdType, data: &[u8], enable_brs: bool, enable_esi: bool) -> Result<(), io::Error> {
        
        if self.can_type == CanType::Classic {
            println!("#INFO: Current device is in Classic CAN mode. Skipping write_data_can_fd.");
            return Ok(());
        }

        if data.len() > crate::utils::CANFD_MAX_DLEN {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "#ERROR: CAN FD data length cannot exceed 64 bytes",
            ));
        }

        let id = match id_type {
            CanIdType::Standard => {
                let std_id = StandardId::new(can_id as u16).ok_or_else(|| {
                    io::Error::new(io::ErrorKind::InvalidInput, "#ERROR: Invalid 11-bit CAN ID (Max: 0x7FF)")
                })?;
                Id::Standard(std_id)
            }
            CanIdType::Extended => {
                let ext_id = ExtendedId::new(can_id).ok_or_else(|| {
                    io::Error::new(io::ErrorKind::InvalidInput, "#ERROR: Invalid 29-bit Extended CAN ID (Max: 0x1FFFFFFF)")
                })?;
                Id::Extended(ext_id)
            }
        };

        let mut frame = CanFdFrame::new(id, data).ok_or_else(|| {
            io::Error::new(io::ErrorKind::Other, "Failed to create CAN FD frame. Check if data length is valid for CAN FD.")
        })?;

        //frame = frame.with_brs(enable_brs).with_esi(enable_esi);

        frame.set_brs(enable_brs);
        frame.set_esi(enable_esi);

        match &self.socket {
            CanSocketKind::Fd(fd_socket) => {
                fd_socket.write_frame(&frame)?;
            }
            _ => {} 
        }

        println!("📤 [CAN FD] Sent ok -> ID: 0x{:X},BRS: {}, ESI: {},Data: {:X?}", can_id, enable_brs, enable_esi,data);
        Ok(())
    }

    pub fn set_recv_filter(&mut self) -> Result<(), Box<dyn std::error::Error>> {

        let filter_amount = crate::utils::input_id_filter_amount();
        let mut filters = Vec::with_capacity(filter_amount as usize);
        //let mut filter_metadata = Vec::with_capacity(filter_amount as usize);
        let filter_metadata: Vec<(u32, CanIdType)> = Vec::with_capacity(filter_amount as usize);

        for i in 1..=filter_amount {
            println!("#Set id message filter{}", i);
            
            let raw_id = crate::utils::input_msg_id()?;

            let frame_type = crate::utils::input_id_filter_frame_type();

            let filter = match frame_type {
                CanIdType::Standard => {
                    let std_id = StandardId::new(raw_id as u16).ok_or("Invalid Standard ID")?;
                    // Mask 0x7FF forces an exact match on all 11 bits
                    CanFilter::new(std_id.as_raw() as u32, 0x7FF)
                }
                CanIdType::Extended => {
                    let ext_id = ExtendedId::new(raw_id).ok_or("Invalid Extended ID")?;
                    // Mask 0x1FFFFFFF forces an exact match on all 29 bits
                    CanFilter::new(ext_id.as_raw(), 0x1FFFFFFF)
                }
            };

            filters.push(filter);
        }

        match &self.socket {
            CanSocketKind::Classic(socket) => {
                if let Err(e) = socket.set_filters(&filters) {
                    println!("#ERROR: Set receive filter fail, error: {}", e);
                    return Err(Box::new(e));
                }
            }
            CanSocketKind::Fd(socket) => {
                if let Err(e) = socket.set_filters(&filters) {
                    println!("#ERROR: Set receive filter fail, error: {}", e);
                    return Err(Box::new(e));
                }
            }
        }

        println!("#INFO: Set receive filter success, filter amount: {}", filter_amount);
        for (i, (raw_id, frame_type)) in filter_metadata.iter().enumerate() {
            let idx = i + 1;
            println!("-----#{} id message filter-----", idx);
            println!("id: x{:08x}", raw_id);
            match frame_type {
                CanIdType::Standard => {
                    println!("frame_type: Standard(0)");
                }
                CanIdType::Extended => {
                    println!("frame_type: Extended(1)");
                }
            }
            println!("-----#{} id message filter-----", idx);
        }

        Ok(())
    }

    pub fn socketcan_clear_recv_filter(&self) -> Result<(), Box<dyn std::error::Error>> {
        
        let clear_filter = [CanFilter::new(0, 0)];
        
        match &self.socket {
            CanSocketKind::Classic(socket) => {
                if let Err(e) = socket.set_filters(&clear_filter) {
                    println!("#ERROR: Clear receive filter fail, error: {}", e);
                    return Err(Box::new(e));
                }
            }
            CanSocketKind::Fd(socket) => {
                if let Err(e) = socket.set_filters(&clear_filter) {
                    println!("#ERROR: Clear receive filter fail, error: {}", e);
                    return Err(Box::new(e));
                }
            }
        }

        println!("#INFO: Clear receive filter success (Reset to receive all frames).");
        Ok(())
    }
}

