/**
 * @file utils.rs
 * @brief cmd list for test SocketCAN function
 * 
 * Copyright (C) 2026, SUNIX Co., Ltd.
 *
 * Authors      : Max Chang <max.chang@sunix.com>
 * 
 * 
**/

use std::io::{self, Write};
use regex::Regex;

const BUFF_LEN: usize = 32;
const MAXIMUM_IDFILTER_AMOUNT: i32 = 32;

pub const CAN_MAX_DLEN: usize = 8;
pub const CANFD_MAX_DLEN: usize = 64;

pub fn input_can_net_device_name() -> Result<String, io::Error> {
    print!("Please input CAN net device name(canxxx)\n");
    io::stdout().flush()?;

    let mut name = String::new();
    io::stdin().read_line(&mut name)?;
    let name = name.trim().to_string();

    if name.is_empty() || name.len() > BUFF_LEN {
        println!("#ERROR: The length of CAN net device name is invalid");
        return Err(io::Error::new(io::ErrorKind::InvalidInput, "Invalid length"));
    }

    let re = Regex::new(r"^(can|vcan)\d+$").unwrap();

    if !re.is_match(&name) {
        println!("#ERROR: Invalid device name format! Expected format like 'can0' or 'vcan1'.");
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "Invalid device name format",
        ));
    }

    Ok(name)
}

pub fn input_msg_id() -> Result<u32, io::Error> {
    
    let mut input_buffer = String::new();

    loop {
            input_buffer.clear();
        
            print!("Input ID, Base:11bits (0~7FF); Extended:29bits (0~1FFFFFFF)\n");
            io::stdout().flush()?;

            io::stdin().read_line(&mut input_buffer)?;
            let trimmed = input_buffer.trim();

            match u32::from_str_radix(trimmed, 16) {
                Ok(id) => {
                    return Ok(id);
                }
                
                Err(_) => {
                    println!("#ERROR: Invalid hex format, please try again.");
                }
            }
    }
}

pub fn input_msg_data() -> Result<Vec<u8>, io::Error> {
    
    let mut input_buffer = String::new();

    loop {
            input_buffer.clear();
            print!("Data ( max 8 bytes, format e.g. 12 34 56 78 90 AB CD EF) \n");
            io::stdout().flush()?;

            io::stdin().read_line(&mut input_buffer)?;
            let trimmed = input_buffer.trim();

            if trimmed.is_empty() {
                println!("#ERROR: Data cannot be empty, please try again.");
                continue;
            }

            let parsed_result: Result<Vec<u8>, _> = trimmed
                .split_whitespace()
                .map(|hex_str| u8::from_str_radix(hex_str, 16))
                .collect();

            match parsed_result {
                
                Ok(data) => {
                
                    let len = data.len();

                    if len < 1 || len > CAN_MAX_DLEN {
                        println!(
                            "#ERROR: Data length must be between 1 and 8 bytes (Current: {} bytes).", len
                        );
                    continue;
                    }

                return Ok(data);
            }
            Err(_) => {
                println!("#ERROR: Invalid hex format! Please use format like '12 34 56 78 90 AB CD EF'.");
            }
        }
    }
}

pub fn input_msg_fd_data() -> Result<Vec<u8>, io::Error> {
    
    let mut input_buffer = String::new();

    loop {
            input_buffer.clear();
            print!("Data ( max 64 bytes, format e.g. 12 34 56 78 90 AB CD EF 12 34 56 78 90 AB CD EF) \n");
            io::stdout().flush()?;

            io::stdin().read_line(&mut input_buffer)?;
            let trimmed = input_buffer.trim();

            if trimmed.is_empty() {
                println!("#ERROR: Data cannot be empty, please try again.");
                continue;
            }

            let parsed_result: Result<Vec<u8>, _> = trimmed
                .split_whitespace()
                .map(|hex_str| u8::from_str_radix(hex_str, 16))
                .collect();

            match parsed_result {
                
                Ok(data) => {
                
                    let len = data.len();

                    if len < 1 || len > CANFD_MAX_DLEN {
                        
                        println!(
                        "#ERROR: Data length must be between 1 and 64 bytes (Current: {} bytes).", len
                        );
                    
                    continue;
                    }

                    return Ok(data);
                }
            
                Err(_) => {
                    println!("#ERROR: Invalid hex format! Please use format like '12 34 56 78 90 AB CD EF 12 34 56 78 90 AB CD EF'.");
                }
        }
    }
}

pub fn input_id_filter_amount() -> i32 {
    
    loop {     
            println!("Set filter amount: (range: 1 ~ {})", MAXIMUM_IDFILTER_AMOUNT);
        
            let _ = io::stdout().flush();

            let mut input = String::new();
              
            if io::stdin().read_line(&mut input).is_err() {
            println!("#ERROR: Failed to read input. Try again.");
            continue;
            }

            match input.trim().parse::<i32>() {
            
            Ok(result) if result > 0 && result <= MAXIMUM_IDFILTER_AMOUNT => {
                return result;
            }
            _ => {                
                println!("#ERROR: Invalid amount. Please enter a number within the range.");
            }
        }
    }
}

pub fn input_id_filter_frame_type() -> crate::socketcan_func_test::CanIdType {
    
    loop {    
            println!("Set filter frame type: 0->standard, 1->extended");

            let _ = io::stdout().flush();

            let mut input = String::new();
            if io::stdin().read_line(&mut input).is_err() {
            println!("#ERROR: Failed to read input.");
            continue;
            }

            match input.trim() {
                
                "0" => return crate::socketcan_func_test::CanIdType::Standard,
                "1" => return crate::socketcan_func_test::CanIdType::Extended,
                _ => {
                    println!("#ERROR: Invalid type. Please enter 0 or 1.");
                }
            }
    }
}