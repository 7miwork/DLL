/**
 * @file main.rs
 * @brief cmd list for test SocketCAN function
 * 
 * Copyright (C) 2026, SUNIX Co., Ltd.
 *
 * Authors      : Max Chang <max.chang@sunix.com>
 * 
 * 
**/

use console::Term;
use std::io::{self, Write};
use std::process::Command;

mod socketcan_func_test;
mod utils;

pub const DATE: &str = "2026/07/01";
pub const VERSION: &str = "1.0.0.0";

#[derive(PartialEq)]
pub enum InputParam {
    Enable,
    Disable,
}

fn print_info() {
    println!("---------------------------------------");
    println!(" Date        : {}", DATE);
    println!(" Version     : {}", VERSION);
    println!("---------------------------------------");
}

fn print_cmd() {
    println!(
">-------------------------------------<
    A : Open 
    B : Close 
    C : Write CAN data
    D : Write CAN FD data
    E : Read CAN data(thread)
    F : Set receive filters
    G : Clear receive filter

    ? : Show cmd
    Q : quit
>-------------------------------------<\n"
    );
}

fn main() -> std::io::Result<()>{
    
    let term = Term::stdout();
    let mut device: Option<crate::socketcan_func_test::SocketCanDevice> = None;

    let _ = Command::new("clear").status();
    print_info();
    println!(
"=========================================================================================
|                                  Socketcan R/W Example                                 |
=========================================================================================
Usage before run program                                                                 |
   Enable CAN device:                                                                    |
       sudo ip link set can0 type can bitrate 1000000                                    |
       sudo ip link set can0 up                                                          |
   or                                                                                    |
   Enable CAN FD device:                                                                 |
       sudo ip link set can0 type can bitrate 1000000 dbitrate 2000000 fd on                                     |
       sudo ip link set can0 up                                                          |
========================================================================================="
    );
    print_cmd();

    loop{
        
        print!("d[#_#]b > CMD ? ");
        io::stdout().flush()?;
        
        let cmd = term.read_char()?;
        println!("{}", cmd);

        match cmd {

            'a' | 'A' => {

                match crate::socketcan_func_test::socketcan_open() {
                   
                    Ok(dev) => {
                        println!("#INFO: Socketcan net device open Success");
                        device = Some(dev);

                    }
                    Err(_) => {
                        println!("#ERROR: Socketcan net device open Fail");
                    }
                }
            }

            'b' | 'B' => {

                if let Some(dev) = device.take() {
                    
                    if let Ok(mut opened) = crate::socketcan_func_test::OPENED_DEVICES.lock() {
                        *opened = None;
                    }
                    
                    println!("#INFO: Socketcan net device [{}] close Success", dev.name);
                } 
                else {
                    println!("#ERROR: Socketcan net device close Fail (Device not open)");
                }
            }

            'c' | 'C' => {

                if let Some(ref dev) = device {

                    println!("Select CAN ID Type: [1] Standard ID (11-bit)  [2] Extended ID (29-bit) ?");
        
                    let id_choice = term.read_char()?;
                    println!("{}", id_choice);

                    let id_type = match id_choice {
                    '2' => crate::socketcan_func_test::CanIdType::Extended,
                      _ => crate::socketcan_func_test::CanIdType::Standard, // Default and '1' is Standard
                    };

                    let target_id = crate::utils::input_msg_id()?;
        
                    let test_data = crate::utils::input_msg_data()?;

                    if let Err(e) = dev.write_data_can(target_id, id_type, &test_data) {
                        eprintln!("#ERROR: Send CAN 2.0 fail: {:?}", e);
                    }
                    } else {
                            println!("#ERROR: Device is not open yet! Please press 'A' first.");
                    }
            }

            'd' | 'D' => {

                if let Some(ref dev) = device {

                    println!("Select CAN ID Type: [1] Standard ID (11-bit)  [2] Extended ID (29-bit) ?");
        
                    let id_choice = term.read_char()?;
                    println!("{}", id_choice);

                    let id_type = match id_choice {
                    '2' => crate::socketcan_func_test::CanIdType::Extended,
                      _ => crate::socketcan_func_test::CanIdType::Standard, // Default and '1' is Standard
                    };

                    let target_id = crate::utils::input_msg_id()?;
        
                    let test_data = crate::utils::input_msg_fd_data()?;

                    if let Err(e) = dev.write_data_can_fd(target_id, id_type, &test_data, true, true) {
                        eprintln!("#ERROR: Send CAN FD fail: {:?}", e);
                    }
                    } else {
                            println!("#ERROR: Device is not open yet! Please press 'A' first.");
                    }
            }

            'e' | 'E' => {

                if let Some(ref dev) = device {
  
                    crate::socketcan_func_test::start_can_receiver(dev);
                } else {
                    println!("#ERROR: Device is not open yet! Please press 'A' first.");
                }

            }

            'f' | 'F' => {
                if let Some(ref mut dev) = device {
                    if let Err(e) = dev.set_recv_filter() {
                        eprintln!("#ERROR: Execute set_recv_filter failed: {:?}", e);
                    }
                } else {
                    println!("#ERROR: Device is not open yet! Please press 'A' first.");
                }
            }

            'g' | 'G' => {
                if let Some(ref mut dev) = device {
                    if let Err(e) = dev.socketcan_clear_recv_filter() {
                        eprintln!("#ERROR: Execute set_recv_filter failed: {:?}", e);
                    }
                } else {
                    println!("#ERROR: Device is not open yet! Please press 'A' first.");
                }
            }

            '?' => {
                print_cmd();
            }
            'q' | 'Q' => {
                println!("#INFO: Quit program.");
                break;
            }
            _ => {
                
            }
        
        }

    }
    
    Ok(())

}
