#! /usr/bin/python3
import j1939
import time
import os
import datetime
import click
import subprocess

HEX_BASE = 16
MAX_PGN = 0x3FFFF
MAX_SA = 0xFF
VERSION = 'V3.0.0.0'
DATE = '2026/08/26'

ecu = j1939.ElectronicControlUnit()
ch = None
is_opened = False


def on_message_callback(priority ,pgn, sa, timestamp, data):
     
    data_print = " ".join(["{0:02X}".format(b) for b in data])
    ts = datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S.%f') #micro seconds

    print(f'******************** Received J1939 Message **********************\r')
    print(f'Timestamp:{ts}\r')
    print(f'Priority:{priority:X}\r')
    print(f'Source Address:{sa:X}\r')
    print(f'PGN:{pgn}, hex format:{pgn:X}\r')
    print(f'Data:{data_print}\r')
    print('*******************************************************************\r')

def J1939TestList():
    cmd = 'cls' if os.name == 'nt' else 'clear'
    subprocess.run([cmd], shell=False)
    print(
    "=========================================================================================\r\n"
    "|                               SocketCAN J1939 S/R Example                            |\r\n"
    "=========================================================================================\r\n"
    )
    print('>------------------------------------<\r')
    print(f'Version:{VERSION}\r')
    print(f'Date:{DATE}\r')
    print('>------------------------------------<\r')
    print('>------------------------------------<\r')
    print('1 : J1939 Socket Open\r')
    print('2 : J1939 Socket Close\r')
    print('3 : Send J1939 Message\r')
    print('4 : Receive J1939 Message\r')

    print()
    print('? : Command list\r')
    print('Q : Quit\r')
    print('>------------------------------------<\r')

def J1939Open():

    global ecu, ch, is_opened


    if is_opened:
        print(f'Info: This program can only open one CAN port at a time, {ch} J1939 socket is opened\r')
        return

    ch_num = input('Channel?(eg: "can0" -> input 0):\r\n').strip()
    if not ch_num.isdigit():
        print('Error: Wrong channel number input\r')
        return

    target_ch = f"can{ch_num}"
    try:
        ecu.connect(bustype='socketcan', channel=target_ch)
        ch = target_ch
        is_opened = True
        print(f'{ch} J1939 socket open success\r')
    except Exception as e:
        is_opened = False
        print(f'Error: {e}\r')       
    
def J1939Close():

    global is_opened

    if not is_opened:
        print(f'{ch} J1939 socket has been closed\r')
        return

    try:
        ecu.disconnect()
        is_opened = False
        print(f'{ch} J1939 socket close success\r')
    except Exception as e:
        print(f'Error: {e}\r')

def SendJ1939Message():

    if not is_opened:
        print('Info: No net device is opened\r')
        return

    pgn_str = input('PGN? (Hex format, range: 0x0 ~ 0x3ffff):\r\n').strip()
    try:
        pgn = int(pgn_str, HEX_BASE)
        if not (0 <= pgn <= MAX_PGN):
            raise ValueError
    except ValueError:
        print('Error: Invalid PGN (must be hex 0x0 ~ 0x3FFFF)\r')
        return

    sa_str = input('Address(SA, Hex format, 1 byte)?:\r\n').strip()
    try:
        sa_val = int(sa_str, HEX_BASE)
        if not (0 <= sa_val <= MAX_SA):
            raise ValueError
    except ValueError:
        print('Error: Invalid SA (must be hex 0x00 ~ 0xFF)\r')
        return

    input_data = input('Data? <= 8bytes(e.g. 12 34 56 78 90 AB CD EF):\r\n').strip()
    try:
        data_bytes = bytes.fromhex(input_data)
        if len(data_bytes) > 8:
            print('Error: Data exceeds 8 bytes\r')
            return
    except ValueError:
        print('Error: Wrong data format input\r')
        return

    #************************************************
    #**29 bit extended CAN-ID************************
    #**[Priority]   [PGN]       [SA(Source Address)]*
    #**[Bit 28...26][Bit 25...8][Bit 7...0]**********
    #************************************************

    #****************************************************************
    #*PGN************************************************************
    # [R(Reserver)][DP(Data Page)][PF(PDU Format)][PS[PDU Specific]]
    # [Bit25]      [Bit24]        [Bit 23...16]   [Bit 15...8]
    #****************************************************************
    
    dp = (pgn >> 16) & 0x03
    pf = (pgn >> 8) & 0xFF
    ps = pgn & 0xFF

    try:
        result = ecu.send_pgn(data_page=dp, pdu_format=pf, pdu_specific=ps, priority=6, src_address=sa_val, data=data_bytes, time_limit=0.1)
        if result is False:
            print(f'Error: {ch} Send J1939 message fail, return: {result}\r')
    except Exception as e:
        print(f'Error: {e}\r')

def ReceiveJ1939Message():

    if not is_opened:
        print('Info: No net device is opened\r')
        return

    try:

        ecu.subscribe(on_message_callback)
        print(f'{ch} waiting for J1939 message...\r')
    except Exception as e:
        print(f'Error: {e}\r')

    
def main():
    global is_opened

    J1939TestList()

    actions = {
        '1': J1939Open,
        '2': J1939Close,
        '3': SendJ1939Message,
        '4': ReceiveJ1939Message,
        '?': J1939TestList,
    }

    while True:
        print('\r\nCMD?\r')
        key = click.getchar().upper()

        if key in actions:
            actions[key]()
        elif key == 'Q':
            if is_opened:
                J1939Close()
            quit()

        time.sleep(0.2)


if __name__ == '__main__':
      main()