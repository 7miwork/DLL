#! /usr/bin/python3
import asyncio
import datetime
import multiprocessing
import os
import secrets
import subprocess
import time
import can
import click
import keyboard

HEX_BASE = 16
CAN_EFF_FLAG = 0x80000000
MAX_SFF_ID = 0x7FF
MAX_EFF_ID = 0x1FFFFFFF
MAX_CAN20_LEN = 8
MAX_CANFD_LEN = 64
CANFD_VALID_DLC_LENGTHS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 12, 16, 20, 24, 32, 48, 64]
VERSION = 'V2.0.0.0'
DATE = '2026/08/26'

r_proc = None
is_listening = False


def _input_channel():

    ch_num = input('Channel?(eg: "can0" -> input 0):\r\n').strip()
    if not ch_num.isdigit():
        print('Error: Wrong channel number input\r')
        return None
    return f"can{ch_num}"


def _input_is_fd():

    is_fd_input = input('CAN2.0/FD?(0:CAN 2.0; 1:CAN FD):\r\n').strip()
    if is_fd_input not in ('0', '1'):
        print('Error: Wrong CAN2.0/FD input\r')
        return None
    return is_fd_input == '1'


def _input_hex(prompt, max_val, error_msg):

    val_str = input(f'{prompt}\r\n').strip()
    try:
        val = int(val_str, HEX_BASE)
        if 0 <= val <= max_val:
            return val
    except ValueError:
        pass
    print(f'{error_msg}\r')
    return None


def _input_positive_float(prompt, error_msg):

    try:
        val = float(input(f'{prompt}\r\n').strip())
        if val > 0:
            return val
    except ValueError:
        pass
    print(f'{error_msg}\r')
    return None


def _input_data_bytes(max_len):

    input_data = input(f'Data? <= {max_len}bytes(e.g. 12 34 56 78 90 AB CD EF):\r\n').strip()
    try:
        data_bytes = bytes.fromhex(input_data)
        if len(data_bytes) > max_len:
            print(f'Error: Data exceeds {max_len} bytes\r')
            return None
        return data_bytes
    except ValueError:
        print('Error: Wrong data format input\r')
        return None


def _print_can_message(title, msg, period=None, duration=None):

    data_print = " ".join(f"{b:02X}" for b in msg.data)
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

    print(f'******************* {title} ********************\r')
    print(f'Timestamp:{ts}\r')
    if period is not None:
        print(f'Period:{period}sec\r')
    if duration is not None:
        print(f'Duration:{duration}sec\r')
    print(f'Channel:{msg.channel}\r')
    print(f'ID:{hex(msg.arbitration_id)}\r')
    print(f'DLC:{msg.dlc}\r')
    print(f'Data:{data_print}\r')
    print(f'FD:{msg.is_fd}\r')
    if msg.is_fd:
        print(f'BRS:{msg.bitrate_switch}\r')
        print(f'ESI:{msg.error_state_indicator}\r')
    print('*****************************************************\r')


def SocketCanTestList():
    cmd = 'cls' if os.name == 'nt' else 'clear'
    subprocess.run([cmd], shell=False)
    print(
    "=========================================================================================\r\n"
    "|                                   Socketcan R/W Example                               |\r\n"
    "=========================================================================================\r\n"
    "Usage before run program                                                                |\r\n"
    "   Enable CAN device:                                                                   |\r\n"
    "       sudo ip link set can0 type can bitrate 1000000                                   |\r\n"
    "       sudo ip link set can0 up                                                         |\r\n"
    "   or                                                                                   |\r\n"
    "   Enable CAN FD device:                                                                |\r\n"
    "       sudo ip link set can0 type can bitrate 1000000 dbitrate 2000000 fd on            |\r\n"
    "       sudo ip link set can0 up                                                         |\r\n"
    "=========================================================================================\r"
    )
    print('>------------------------------------<\r')
    print(f'Version:{VERSION}\r')
    print(f'Date:{DATE}\r')
    print('>------------------------------------<\r')
    print('>------------------------------------<\r')
    print('1 : Send a CAN frame\r')
    print('2 : Send a CAN FD frame\r')
    print('3 : Send a Random CAN frame\r')
    print('4 : Send a Random CAN FD frame\r')
    print('5 : Send period CAN frame\r')
    print('6 : Send period CAN FD frame\r')
    print('7 : Send period CAN frame(Random data)\r')
    print('8 : Send period CAN FD frame(Random Data)\r')
    print('9 : Receive CAN frame\r')
    print('0 : Receive CAN frame with filter\r')
    print('A : Receive CAN frame by listener(BufferedReader)\r')
    print('B : Receive CAN frame by listener(AsyncBufferedReader)\r')
    print('C : End the listener\r')
    print('\r\n? : Command list\r')
    print('Q : Quit\r')
    print('>------------------------------------<\r')

def _send_frame(is_fd, is_random, is_periodic):

    channel = _input_channel()
    if not channel:
        return

    arb_id = _input_hex('ID?(Base:11bits; Extended:29bits): ', MAX_EFF_ID, 'Error: Invalid CAN ID')
    if arb_id is None:
        return

    max_len = MAX_CANFD_LEN if is_fd else MAX_CAN20_LEN
    if is_random:
        if is_fd:
            data_len = secrets.choice(CANFD_VALID_DLC_LENGTHS)
        else:
            data_len = secrets.randbelow(MAX_CAN20_LEN + 1)
        data_bytes = secrets.token_bytes(data_len)
    else:
        data_bytes = _input_data_bytes(max_len)
        if data_bytes is None:
            return

    period_val, duration_val = None, None
    if is_periodic:
        period_val = _input_positive_float('Period ?(in seconds between messages): ', 'Error: Wrong period input')
        if period_val is None:
            return
        duration_val = _input_positive_float('Duration ?(in seconds to continue): ', 'Error: Wrong duration input')
        if duration_val is None:
            return

    msg = can.Message(
        arbitration_id=arb_id,
        data=data_bytes,
        is_extended_id=(arb_id > MAX_SFF_ID),
        is_fd=is_fd,
        bitrate_switch=is_fd,
        channel=channel
    )

    try:
        with can.interface.Bus(interface='socketcan', channel=channel, fd=is_fd) as bus:
            if is_periodic:
                task = bus.send_periodic(msg, period=period_val, duration=duration_val)
                _print_can_message('Period Message Sent', msg, period=period_val, duration=duration_val)
                time.sleep(duration_val)
                task.stop()
            else:
                bus.send(msg)
                _print_can_message('Message Sent', msg)
    except can.CanError as e:
        print(f'CAN Error: {e}\r')


def SendFrame():               _send_frame(is_fd=False, is_random=False, is_periodic=False)
def SendFdFrame():             _send_frame(is_fd=True,  is_random=False, is_periodic=False)
def SendRandomFrame():         _send_frame(is_fd=False, is_random=True,  is_periodic=False)
def SendRandomFdFrame():       _send_frame(is_fd=True,  is_random=True,  is_periodic=False)
def SendPeriodFrame():         _send_frame(is_fd=False, is_random=False, is_periodic=True)
def SendPeriodFdFrame():       _send_frame(is_fd=True,  is_random=False, is_periodic=True)
def SendPeriodRandomFrame():   _send_frame(is_fd=False, is_random=True,  is_periodic=True)
def SendPeriodRandomFdFrame(): _send_frame(is_fd=True,  is_random=True,  is_periodic=True)


def CanRecv(ch_name, is_fd_bool, can_filters=None):
    try:
        with can.interface.Bus(interface='socketcan', channel=ch_name, fd=is_fd_bool, can_filters=can_filters) as bus:
            while True:
                rev_msg = bus.recv()
                if rev_msg is not None:
                    _print_can_message('Received Message', rev_msg)
                    print('\r\n********* press "esc" key to end receive mode *********\r\n')
    except can.CanError as e:
        print(f'CAN Error: {e}\r')
    except Exception:
        pass


def CanListen(ch_name, is_fd_bool):
    rx_buff = can.listener.BufferedReader()
    try:
        with can.interface.Bus(interface='socketcan', channel=ch_name, fd=is_fd_bool) as bus:
            notifier = can.Notifier(bus, [rx_buff])
            while True:
                rev_msg = rx_buff.get_message()
                if rev_msg is not None:
                    _print_can_message('Message Notification', rev_msg)
    except can.CanError as e:
        print(f'CAN Error: {e}\r')
    except Exception:
        pass


async def AsyncCanListen(ch_name, is_fd_bool):
    rx_buff = can.listener.AsyncBufferedReader()
    loop = asyncio.get_running_loop()
    bus = can.interface.Bus(interface='socketcan', channel=ch_name, fd=is_fd_bool)
    notifier = can.Notifier(bus, [rx_buff], loop=loop)

    try:
        while True:
            try:
                rev_msg = await rx_buff.get_message()
                if rev_msg is not None:
                    _print_can_message('Message Notification', rev_msg)
            except can.CanError as e:
                print(f'CAN Error: {e}\r')
    finally:
        notifier.stop()
        bus.shutdown()


def _run_async_listener(ch_name, is_fd_bool):
    asyncio.run(AsyncCanListen(ch_name, is_fd_bool))


def ReceiveFrame():
    channel = _input_channel()
    if not channel:
        return

    is_fd = _input_is_fd()
    if is_fd is None:
        return

    r_proc = multiprocessing.Process(target=CanRecv, args=(channel, is_fd), daemon=True)
    r_proc.start()

    print('Start receiving data, press "esc" key to end receive mode.\r')
    keyboard.wait('esc')

    r_proc.terminate()
    r_proc.join()
    print('Receive mode ended.\r')

def ReceiveFrameWithFilter():
    print('Tip: Socket can filter formula: received_can_id & mask = code_id & mask\r')

    channel = _input_channel()
    if not channel:
        return

    is_fd = _input_is_fd()
    if is_fd is None:
        return

    base_id = _input_hex('Set a base code ID for base filter?: ', MAX_SFF_ID, 'Error: Wrong base code ID input')
    if base_id is None:
        return

    base_mask = _input_hex('Set a base mask for base filter?: ', MAX_SFF_ID, 'Error: Wrong base mask input')
    if base_mask is None:
        return

    ext_id = _input_hex('Set a extended code ID for extended filter?: ', MAX_EFF_ID, 'Error: Wrong extended code ID input')
    if ext_id is None:
        return

    ext_mask = _input_hex('Set a extended mask for extended filter?: ', MAX_EFF_ID, 'Error: Wrong extended mask input')
    if ext_mask is None:
        return

    filters = [
        {"can_id": base_id, "can_mask": base_mask | CAN_EFF_FLAG, "extended": False},
        {"can_id": ext_id | CAN_EFF_FLAG, "can_mask": ext_mask | CAN_EFF_FLAG, "extended": True}
    ]

    r_proc = multiprocessing.Process(target=CanRecv, args=(channel, is_fd, filters), daemon=True)
    r_proc.start()

    print('Start receiving data, press "esc" key to end receive mode.\r')
    keyboard.wait('esc')

    r_proc.terminate()
    r_proc.join()
    print('Receive mode ended.\r')


def _start_background_listener(target_worker, async_mode=False):

    global is_listening, r_proc

    if is_listening:
        print('Error: Listener has now been started\r')
        return

    channel = _input_channel()
    if not channel:
        return

    is_fd = _input_is_fd()
    if is_fd is None:
        return

    r_proc = multiprocessing.Process(target=target_worker, args=(channel, is_fd), daemon=True)
    r_proc.start()
    is_listening = True
    mode_str = "asynchronous " if async_mode else ""
    print(f'{channel} start {mode_str}listening...\r')


def ReceiveFrameByListener():
    _start_background_listener(CanListen, async_mode=False)


def ReceiveFrameByAsynListener():
    _start_background_listener(_run_async_listener, async_mode=True)


def EndListen():

    global r_proc, is_listening

    if r_proc is not None:
        r_proc.terminate()
        r_proc.join()
        r_proc = None
        is_listening = False
        print('End listening...\r')
    else:
        print('listener is now closed\r')

def main():

    global is_listening

    SocketCanTestList()

    actions = {
        '1': SendFrame,
        '2': SendFdFrame,
        '3': SendRandomFrame,
        '4': SendRandomFdFrame,
        '5': SendPeriodFrame,
        '6': SendPeriodFdFrame,
        '7': SendPeriodRandomFrame,
        '8': SendPeriodRandomFdFrame,
        '9': ReceiveFrame,
        '0': ReceiveFrameWithFilter,
        'A': ReceiveFrameByListener,
        'B': ReceiveFrameByAsynListener,
        'C': EndListen,
        '?': SocketCanTestList,
    }

    while True:
        print('\r\nCMD?\r')
        key = click.getchar().upper()

        if key in actions:
            actions[key]()
        elif key == 'Q':
            if is_listening:
                EndListen()
            quit()

        time.sleep(0.2)

if __name__ == '__main__':
    main()