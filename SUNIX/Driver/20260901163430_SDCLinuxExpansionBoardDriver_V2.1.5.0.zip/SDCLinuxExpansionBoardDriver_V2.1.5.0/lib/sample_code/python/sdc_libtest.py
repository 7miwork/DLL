#!/usr/bin/python3
import ctypes as ct
import os
import time
import click
import subprocess

sdc = ct.CDLL('/usr/lib/libsdc.so.2.0.0')

SDC_DIO_BANK_MAX = 32
STATUS_SUCCESS = 0
VERSION = 'V2.0.0.0'
DATE = '2026/09/01'

class BankInfoStruct(ct.Structure):
    _fields_ = [
        ("nr_port", ct.c_int),
        ("cap_input", ct.c_int),
        ("cap_output", ct.c_int),
        ("cap_rising_trigger", ct.c_int),
        ("cap_falling_trigger", ct.c_int),
    ]

class DioInfoStruct(ct.Structure):
    _fields_ = [
        ("pci_bus", ct.c_int),
        ("irq", ct.c_int),
        ("line", ct.c_int),
        ("index", ct.c_int),
        ("version", ct.c_int),
        ("cap_samedirection", ct.c_int),
        ("cap_storeflash", ct.c_int),
        ("nr_bank", ct.c_int),
        ("di_sampling_freq", ct.c_int),
        ("di_filter_lower_bound_ms", ct.c_int),
        ("di_filter_min_ms", ct.c_int),
        ("di_filter_max_ms", ct.c_int),
        ("BankInfoList", BankInfoStruct * SDC_DIO_BANK_MAX),
    ]

CALLBACK_FUNC_TYPE = ct.CFUNCTYPE(None, ct.c_int, ct.c_int, ct.c_int, ct.c_int)
_active_callbacks = {}

def prompt_int(prompt_text):

    val = input(f"{prompt_text}:\r\n").strip()
    if val.isdigit():
        return int(val)
    print(f"Error: '{val}' is not a valid positive integer.")
    return None

def prompt_hex(prompt_text, hex_len=8):

    val = input(f"{prompt_text} (e.g. {'0' * (hex_len - 2)}FF):\r\n").strip()
    if len(val) == hex_len:
        try:
            return int(val, 16)
        except ValueError:
            pass
    print(f"Error: '{val}' is not a valid {hex_len}-digit hex string.")
    return None

def input_event_callback(line, bank_idx, input_val, input_delta):
    print("\n" + "=" * 40)
    print(f" [!] Input Event Triggered on Line {line}, Bank {bank_idx}")
    print(f"     Input Delta: 0x{input_delta:08X}")
    print(f"     Input Value: 0x{input_val:08X}")
    print("=" * 40 + "\nCMD ? ", end='', flush=True)

def show_menu():
    cmd = 'cls' if os.name == 'nt' else 'clear'
    subprocess.run([cmd], shell=False)
    
    print(
    "========================================================================================\r\n"
    "|                                      SDC_DIO Example                                 |\r\n"
    "========================================================================================\r\n"
    )
    print('>------------------------------------<\r')
    print(f'Version:{VERSION}\r')
    print(f'Date:{DATE}\r')
    print('>------------------------------------<\r')
    print('>------------------------------------<\r')
    print('1 : DIO Open\r')
    print('2 : DIO Close\r')
    print('A : Get DIO Information\r')
    print('B : Set DIO Bank State\r')
    print('C : Get DIO Bank State\r')
    print('D : Set input rising/falling event control\r')
    print('E : Get input rising/falling event control\r')
    print('F : Register input event callback function\r')
    print('G : Unregister input event callback function\r')
    print()
    print('? : Command list\r')
    print('Q : Quit\r')
    print('>------------------------------------<\r')

def sdc_dio_open():
    line = prompt_int("line?(positive integer)")
    if line is None: return
    
    ret = sdc.sdc_dio_open(line)
    status = "ok" if ret == STATUS_SUCCESS else f"fail (ret={ret})"
    print(f"###################################################\nsdc_dio_open {status}\n###################################################")

def sdc_dio_close():
    line = prompt_int("line?(positive integer)")
    if line is None: return

    ret = sdc.sdc_dio_close(line)
    status = "ok" if ret == STATUS_SUCCESS else f"fail (ret={ret})"
    print(f"###################################################\nsdc_dio_close {status}\n###################################################")

def sdc_dump_dio_info():
    line = prompt_int("line?(positive integer)")
    if line is None: return

    info = DioInfoStruct()
    ret = sdc.sdc_dio_get_info(line, ct.byref(info))
    print(f"sdc_dio_get_info return code: {ret}")

    if ret != STATUS_SUCCESS:
        print("sdc_dio_get_info fail")
        return

    print("###################################################")
    print(f"PCI Bus Number: {info.pci_bus}\nIRQ: {info.irq}\nLine: {info.line}\nIndex: {info.index}")
    print(f"Version: {info.version}\nSame direction cap: {info.cap_samedirection}\nStore flash cap: {info.cap_storeflash}")
    print(f"Number of bank: {info.nr_bank}\nDI sampling freq(Hz): {info.di_sampling_freq}")
    print(f"DI filter bound/min/max(ms): {info.di_filter_lower_bound_ms}/{info.di_filter_min_ms}/{info.di_filter_max_ms}")

    for i in range(info.nr_bank):
        bank = info.BankInfoList[i]
        dio_type = []
        if bank.cap_input: dio_type.append("Input")
        if bank.cap_output: dio_type.append("Output")
        
        print(f"=============== Bank: {i} ===============")
        print(f"DIO Amount: {bank.nr_port}")
        print(f"DIO Type: {' / '.join(dio_type) if dio_type else 'None'}")
        print(f"DI event rising/falling trigger cap: {bank.cap_rising_trigger} / {bank.cap_falling_trigger}")
    print("###################################################")

def sdc_set_dio_state():
    line = prompt_int("line?(positive integer)")
    if line is None: return
    bank = prompt_int("Bank Index?(0:input / 1:output)")
    if bank is None: return
    state = prompt_hex("State?(4 byte hex value)")
    if state is None: return

    ret = sdc.sdc_dio_set_bank_state(line, bank, state)
    if ret == STATUS_SUCCESS:
        print(f"#Set Bank:{bank} State: 0x{state:08X}")
    else:
        print(f"#Set Bank:{bank} fail, Return: {ret} (check if DIO type matches)")

def sdc_get_dio_state():
    line = prompt_int("line?(positive integer)")
    if line is None: return
    bank = prompt_int("Bank Index?(0:input / 1:output)")
    if bank is None: return

    state = ct.c_int()
    ret = sdc.sdc_dio_get_bank_state(line, bank, ct.byref(state))
    if ret == STATUS_SUCCESS:
        print(f"#Get Bank:{bank} State: 0x{state.value:08X}")
    else:
        print(f"#Get Bank:{bank} fail, Return: {ret}")

def sdc_set_inp_evt():
    line = prompt_int("line?(positive integer)")
    if line is None: return
    bank = prompt_int("Bank Index?(0:input / 1:output)")
    if bank is None: return
    rising = prompt_hex("Rising edge event?(4 byte hex value)")
    if rising is None: return
    falling = prompt_hex("Falling edge event?(4 byte hex value)")
    if falling is None: return

    ret = sdc.sdc_dio_set_bank_input_event_ctrl(line, bank, rising, falling)
    if ret == STATUS_SUCCESS:
        print(f"###################################################\n"
              f"#Set Bank:{bank} Rising: 0x{rising:08X}, Falling: 0x{falling:08X}\n"
              f"###################################################")
    else:
        print(f"#Set Bank:{bank} input event control fail, Return: {ret}")

def sdc_get_inp_evt():
    line = prompt_int("line?(positive integer)")
    if line is None: return
    bank = prompt_int("Bank Index?(0:input / 1:output)")
    if bank is None: return

    rising, falling = ct.c_int(), ct.c_int()
    ret = sdc.sdc_dio_get_bank_input_event_ctrl(line, bank, ct.byref(rising), ct.byref(falling))
    if ret == STATUS_SUCCESS:
        print(f"###################################################\n"
              f"#Get Bank:{bank} Rising: 0x{rising.value:08X}, Falling: 0x{falling.value:08X}\n"
              f"###################################################")
    else:
        print(f"#Get Bank:{bank} input event control fail, Return: {ret}")

def sdc_reg_inp_evt_callback():
    line = prompt_int("line?(positive integer)")
    if line is None: return

    cb_func = CALLBACK_FUNC_TYPE(input_event_callback)
    _active_callbacks[line] = cb_func

    ret = sdc.sdc_dio_register_event_callback(line, cb_func)
    status = "ok" if ret == STATUS_SUCCESS else f"fail, Return: {ret}"
    print(f"###################################################\nsdc_dio_register_event_callback {status}\n###################################################")

def sdc_unreg_inp_evt_callback():
    line = prompt_int("line?(positive integer)")
    if line is None: return

    ret = sdc.sdc_dio_unregister_event_callback(line)
    _active_callbacks.pop(line, None)
    
    status = "ok" if ret == STATUS_SUCCESS else f"fail, Return: {ret}"
    print(f"###################################################\nsdc_dio_unregister_event_callback {status}\n###################################################")


def main():
    actions = {
        '1': sdc_dio_open,
        '2': sdc_dio_close,
        'A': sdc_dump_dio_info,
        'B': sdc_set_dio_state,
        'C': sdc_get_dio_state,
        'D': sdc_set_inp_evt,
        'E': sdc_get_inp_evt,
        'F': sdc_reg_inp_evt_callback,
        'G': sdc_unreg_inp_evt_callback,
        '?': show_menu,
        'Q': quit,
    }

    show_menu()

    while True:
        print('\nCMD ?')
        key = click.getchar().upper()

        action = actions.get(key)
        if action:
            action()

        time.sleep(0.2)


if __name__ == '__main__':
    main()