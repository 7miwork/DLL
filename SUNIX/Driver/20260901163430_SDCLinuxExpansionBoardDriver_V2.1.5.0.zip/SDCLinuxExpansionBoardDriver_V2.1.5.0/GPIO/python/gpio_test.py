#!/usr/bin/python3
import os
import threading
import time
import click
import gpiod
import subprocess
from gpiod.edge_event import EdgeEvent
from gpiod.line import Direction, Edge, Value

GPIO_DEV_PATH = "/dev"

gpio_chip_device_name = None
gpio_chip = None


def GpioTestList():
    cmd = 'cls' if os.name == 'nt' else 'clear'
    subprocess.run([cmd], shell=False)
    ListGpioChips()
    print(">------------------------------------<\r")
    print("1 : GPIO Chip Open\r")
    print("2 : GPIO Chip Close\r")
    print("3 : Get Chip Line List\r")
    print("4 : Set Output Value\r")
    print("5 : Get Input Value\r")
    print("6 : Wait Input Event\r")
    print()
    print("? : Command list\r")
    print("Q : Quit\r")
    print(">------------------------------------<\r")


def ListGpioChips():
    print("=======================================================\r")
    print("Available GPIO chips in the system:\r")
    print(f"{'Name':<15}{'Label':<30}{'Lines'}\r")

    for entry in sorted(os.listdir(GPIO_DEV_PATH)):
        if entry.startswith("gpiochip"):
            chip_path = os.path.join(GPIO_DEV_PATH, entry)
            try:
                with gpiod.Chip(chip_path) as chip:
                    info = chip.get_info()
                    label = info.label or "[No Label]"
                    print(f"{entry:<15}{label:<30}{info.num_lines}\r")
            except Exception as e:
                print(f"{entry:<15}[Failed to open: {e}]\r")

    print("=======================================================\r")


def GpioChipOpen():
    global gpio_chip_device_name, gpio_chip

    ch_num = input("GPIO device number (e.g. if /dev/gpiochip1, input 1)? ").strip()
    if not ch_num.isdigit():
        print("Error: Wrong GPIO device number input")
        return

    dev_name = f"/dev/gpiochip{ch_num}"
    try:
        if gpio_chip:
            gpio_chip.close()
        gpio_chip = gpiod.Chip(dev_name)
        gpio_chip_device_name = dev_name
        print(f"Open {gpio_chip_device_name} Successfully")
    except Exception as e:
        print(f"Error opening GPIO chip {dev_name}: {e}")


def GpioChipClose():
    global gpio_chip_device_name, gpio_chip

    if gpio_chip:
        gpio_chip.close()
        gpio_chip = None
        print(f"{gpio_chip_device_name} closed")
        gpio_chip_device_name = None
    else:
        print("No GPIO chip is currently open.")


def GetChipLines():
    if not gpio_chip:
        print("Error: Please open a GPIO chip first.")
        return

    try:
        info = gpio_chip.get_info()
        print(f"==========={gpio_chip_device_name} lines: {info.num_lines}===========")
        for offset in range(info.num_lines):
            line_info = gpio_chip.get_line_info(offset)
            dir_name = line_info.direction.name if line_info.direction else "UNKNOWN"
            name = line_info.name or "-"
            used = "Used" if line_info.used else "Unused"
            print(f"line {offset:<3} | Name: {name:<12} | Dir: {dir_name:<7} | {used}")
        print("=============================================")
    except Exception as e:
        print(f"Error getting line info: {e}")


def GpioChipSetOutput():
    if not gpio_chip:
        print("Error: Please open a GPIO chip first.")
        return

    line_input = input("GPIO line offset number? ").strip()
    if not line_input.isdigit():
        print("Error: Line offset must be an integer.")
        return
    offset = int(line_input)

    val_input = input("Output value (0 or 1)? ").strip()
    if val_input not in ("0", "1"):
        print("Error: Value must be 0 or 1.")
        return

    target_val = Value.ACTIVE if val_input == "1" else Value.INACTIVE
    settings = gpiod.LineSettings(direction=Direction.OUTPUT, output_value=target_val)

    try:
        with gpio_chip.request_lines(
            config={offset: settings},
            consumer="gpio_output_test",
        ) as request:
            request.set_value(offset, target_val)
            print(f"{gpio_chip_device_name} line {offset} set to {val_input}")
    except Exception as e:
        print(f"GPIO Output Error: {e}")


def GpioChipGetInput():
    if not gpio_chip:
        print("Error: Please open a GPIO chip first.")
        return

    line_input = input("GPIO line offset number? ").strip()
    if not line_input.isdigit():
        print("Error: Line offset must be an integer.")
        return
    offset = int(line_input)

    settings = gpiod.LineSettings(direction=Direction.INPUT)

    try:
        with gpio_chip.request_lines(
            config={offset: settings},
            consumer="gpio_input_test",
        ) as request:
            val = request.get_value(offset)
            result_str = "1 (ACTIVE)" if val == Value.ACTIVE else "0 (INACTIVE)"
            print(f"{gpio_chip_device_name} line {offset} read value: {result_str}")
    except Exception as e:
        print(f"GPIO Input Error: {e}")


def WaitInputEvent():
    if not gpio_chip:
        print("Error: Please open a GPIO chip first.")
        return

    line_input = input("GPIO line offset number? ").strip()
    if not line_input.isdigit():
        print("Error: Line offset must be an integer.")
        return
    offset = int(line_input)

    settings = gpiod.LineSettings(
        direction=Direction.INPUT,
        edge_detection=Edge.BOTH,
    )

    try:
        with gpio_chip.request_lines(
            config={offset: settings},
            consumer="gpio_event_test",
        ) as request:
            stop_event = threading.Event()

            def event_loop():
                while not stop_event.is_set():

                    if request.wait_edge_events(timeout=0.2):
                        for event in request.read_edge_events():
                            edge_name = "RISING" if event.event_type == EdgeEvent.Type.RISING_EDGE else "FALLING"
                            timestamp_sec = event.timestamp_ns / 1e9
                            print(f"\n[Event] Line {event.line_offset} {edge_name} Edge | Timestamp: {timestamp_sec:.6f}s")

            worker = threading.Thread(target=event_loop, daemon=True)
            worker.start()

            print(f"Listening on line {offset} (BOTH EDGES)... Press [ENTER] to exit.")
            input()
            stop_event.set()
            worker.join()
            print("Event listener stopped.")

    except Exception as e:
        print(f"GPIO Event Error: {e}")


def main():
    actions = {
        "1": GpioChipOpen,
        "2": GpioChipClose,
        "3": GetChipLines,
        "4": GpioChipSetOutput,
        "5": GpioChipGetInput,
        "6": WaitInputEvent,
        "?": GpioTestList,
    }

    GpioTestList()
    try:
        while True:
            print("\nCMD? (Press '?' to show menu)")
            key = click.getchar()

            if key in ("q", "Q"):
                break

            action = actions.get(key)
            if action:
                action()

            time.sleep(0.1)
    except KeyboardInterrupt:
        pass
    finally:
        if gpio_chip:
            gpio_chip.close()
        print("\nExiting...")


if __name__ == "__main__":
    main()