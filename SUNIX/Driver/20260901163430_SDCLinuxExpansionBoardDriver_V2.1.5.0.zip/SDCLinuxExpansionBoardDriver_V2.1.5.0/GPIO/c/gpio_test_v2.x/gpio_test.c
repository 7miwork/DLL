/**
 * @file gpio_test.c
 * @brief cmd list for test GPIO function (Ported to libgpiod v2.x)
 * 
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * Copyright (C) 2025, SUNIX Co., Ltd.
 *
 * Authors      : Max Chang <max.chang@sunix.com>
 * 
**/

#include "precomp.h"
#include <gpiod.h>
#include <dirent.h>
#include <termios.h>
#include <unistd.h>
#include <pthread.h>
#include <inttypes.h>

#define ESC_KEY 27
#define GPIO_CLASS_PATH "/dev/"

volatile int running = 1; 

char gpio_chip_path[64];
struct gpiod_chip *chip = NULL;

struct termios oldt;

void set_terminal_mode(void) {
    struct termios newt;
    tcgetattr(STDIN_FILENO, &oldt);  
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);  
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
}

void reset_terminal_mode(void) {
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
}

void *keyboard_listener(void *arg) {
    (void)arg;
    char key;
    while (running) {
        if (read(STDIN_FILENO, &key, 1) > 0) {
            if (key == ESC_KEY) {
                printf("\nStop waiting GPIO event...\n");
                running = 0;
                break;
            }
        }
        usleep(50000); 
    }
    return NULL;
}

static void _print_gpio_cmd(void)
{
    printf(">>------------------------------------<<\n");
    printf("     A : GPIO Chip Open\n");
    printf("     B : GPIO Chip Close\n");
    printf("     C : Get Chip Line List\n");
    printf("     D : Set Output Value\n");
    printf("     E : Get Input Value\n");
    printf("     F : Wait Input Event\n");
    printf("\n");
    printf("     Q : quit\n");
    printf(">>------------------------------------<<\n\n");
}

void list_gpio_chips(void)
{
    struct dirent *entry;
    DIR *dir = opendir(GPIO_CLASS_PATH);

    if (!dir) {
        perror("Failed to open GPIO directory");
        return;
    }

    printf("=======================================================\r\n");
    printf("Available GPIO chips in the system:\r\n");
    printf("Name\t\tLabel\t\t\t\tLines\r\n");

    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, "gpiochip", 8) == 0) {
            char chip_path[256];
            snprintf(chip_path, sizeof(chip_path), "%s%.240s", GPIO_CLASS_PATH, entry->d_name);

            struct gpiod_chip *c = gpiod_chip_open(chip_path);
            if (!c) {
                printf("%s\t\t[Failed to open]\n", entry->d_name);
                continue;
            }

            struct gpiod_chip_info *info = gpiod_chip_get_info(c);
            if (info) {
                const char *label = gpiod_chip_info_get_label(info);
                size_t num_lines = gpiod_chip_info_get_num_lines(info);
                printf("%s\t%-30s\t%zu\n", entry->d_name, label ? label : "[No Label]", num_lines);
                gpiod_chip_info_free(info);
            }

            gpiod_chip_close(c);
        }
    }
    printf("=======================================================\r\n");
    closedir(dir);
}

void gpio_chip_open(void)
{
    int n = input_gpio_device_number();
        
    snprintf(gpio_chip_path, sizeof(gpio_chip_path), "/dev/gpiochip%d", n);

    if (chip) {
        gpiod_chip_close(chip);
        chip = NULL;
    }

    chip = gpiod_chip_open(gpio_chip_path);
    if (!chip) {
        printf("Error opening GPIO chip: %s\r\n", gpio_chip_path);
    } else {
        printf("Open %s Successfully\r\n", gpio_chip_path);
    }
}

void gpio_chip_close(void)
{
    if (chip) {
        gpiod_chip_close(chip);
        chip = NULL;
        printf("%s closed\r\n", gpio_chip_path);
    }
}

void get_chip_lines(void)
{
    if (!chip) {
        printf("Error: GPIO chip is not opened\r\n");
        return;
    }

    struct gpiod_chip_info *info = gpiod_chip_get_info(chip);
    if (!info) {
        printf("Failed to get chip info\r\n");
        return;
    }

    size_t num_lines = gpiod_chip_info_get_num_lines(info);
    printf("========== %s:%zu lines ==========\r\n", gpio_chip_path, num_lines);
    gpiod_chip_info_free(info);

    for (size_t i = 0; i < num_lines; i++) {
        struct gpiod_line_info *line_info = gpiod_chip_get_line_info(chip, i);
        if (!line_info) {
            printf("Error to get: line%zu\n", i);
            continue;
        }

        enum gpiod_line_direction direction = gpiod_line_info_get_direction(line_info);
        const char *dir = (direction == GPIOD_LINE_DIRECTION_INPUT) ? "Input" :
                          (direction == GPIOD_LINE_DIRECTION_OUTPUT) ? "Output" : "Unknown";

        const char *name = gpiod_line_info_get_name(line_info);
        printf("line%zu\t name:%-15s direction:%s\n", i, name ? name : "[unnamed]", dir);

        gpiod_line_info_free(line_info);
    }
    printf("=============================================\r\n");
}

void gpio_chip_set_output(void)
{
    if (!chip) {
        printf("Error: gpiod_chip is null\r\n");
        return;
    }

    unsigned int line_num = (unsigned int)input_line_number();
    int value = input_gpio_output_level_value();

    struct gpiod_line_settings *settings = gpiod_line_settings_new();
    struct gpiod_line_config *line_cfg = gpiod_line_config_new();
    struct gpiod_request_config *req_cfg = gpiod_request_config_new();

    if (!settings || !line_cfg || !req_cfg) {
        printf("Error allocating gpiod config objects\r\n");
        goto cleanup;
    }

    gpiod_line_settings_set_direction(settings, GPIOD_LINE_DIRECTION_OUTPUT);
    gpiod_line_settings_set_output_value(settings, 
        value ? GPIOD_LINE_VALUE_ACTIVE : GPIOD_LINE_VALUE_INACTIVE);

    gpiod_line_config_add_line_settings(line_cfg, &line_num, 1, settings);
    gpiod_request_config_set_consumer(req_cfg, "gpio_output");

    struct gpiod_line_request *request = gpiod_chip_request_lines(chip, req_cfg, line_cfg);
    if (!request) {
        printf("Set output value fail, line:%u, GPIO chip:%s\r\n", line_num, gpio_chip_path);
    } else {
        printf("Set output value successfully, line:%u, GPIO chip:%s\r\n", line_num, gpio_chip_path);
        gpiod_line_request_release(request);
    }

cleanup:
    if (settings) gpiod_line_settings_free(settings);
    if (line_cfg) gpiod_line_config_free(line_cfg);
    if (req_cfg) gpiod_request_config_free(req_cfg);
}

void gpio_chip_get_input(void)
{
    if (!chip) {
        printf("Error: gpiod_chip is null\r\n");
        return;
    }

    unsigned int line_num = (unsigned int)input_line_number();

    struct gpiod_line_settings *settings = gpiod_line_settings_new();
    struct gpiod_line_config *line_cfg = gpiod_line_config_new();
    struct gpiod_request_config *req_cfg = gpiod_request_config_new();

    if (!settings || !line_cfg || !req_cfg) {
        printf("Error allocating gpiod config objects\r\n");
        goto cleanup;
    }

    gpiod_line_settings_set_direction(settings, GPIOD_LINE_DIRECTION_INPUT);
    gpiod_line_config_add_line_settings(line_cfg, &line_num, 1, settings);
    gpiod_request_config_set_consumer(req_cfg, "gpio_input");

    struct gpiod_line_request *request = gpiod_chip_request_lines(chip, req_cfg, line_cfg);
    if (!request) {
        printf("Get input value fail (request failed), line:%u, GPIO chip:%s\r\n", line_num, gpio_chip_path);
        goto cleanup;
    }

    enum gpiod_line_value val = gpiod_line_request_get_value(request, line_num);
    if (val == GPIOD_LINE_VALUE_ERROR) {
        printf("Get input value fail, line:%u, GPIO chip:%s\r\n", line_num, gpio_chip_path);
    } else {
        printf("line%u input value:%d\r\n", line_num, (val == GPIOD_LINE_VALUE_ACTIVE) ? 1 : 0);
    }

    gpiod_line_request_release(request);

cleanup:
    if (settings) gpiod_line_settings_free(settings);
    if (line_cfg) gpiod_line_config_free(line_cfg);
    if (req_cfg) gpiod_request_config_free(req_cfg);
}

void gpio_chip_wait_input_event(void)
{   
    if (!chip) {
        printf("Error: gpiod_chip is null\r\n");
        return;
    }

    unsigned int line_num = (unsigned int)input_line_number();

    struct gpiod_line_settings *settings = gpiod_line_settings_new();
    struct gpiod_line_config *line_cfg = gpiod_line_config_new();
    struct gpiod_request_config *req_cfg = gpiod_request_config_new();
    struct gpiod_edge_event_buffer *event_buf = gpiod_edge_event_buffer_new(16);

    if (!settings || !line_cfg || !req_cfg || !event_buf) {
        printf("Error allocating event objects\r\n");
        goto cleanup;
    }

    gpiod_line_settings_set_direction(settings, GPIOD_LINE_DIRECTION_INPUT);
    gpiod_line_settings_set_edge_detection(settings, GPIOD_LINE_EDGE_BOTH);

    gpiod_line_config_add_line_settings(line_cfg, &line_num, 1, settings);
    gpiod_request_config_set_consumer(req_cfg, "gpio_event");

    struct gpiod_line_request *request = gpiod_chip_request_lines(chip, req_cfg, line_cfg);
    if (!request) {
        printf("Error: gpiod_chip_request_lines for events failed\r\n");
        goto cleanup;
    }

    set_terminal_mode();
    pthread_t thread;
    pthread_create(&thread, NULL, keyboard_listener, NULL);

    printf("Waiting line%u event...press 'Esc' to exit\r\n", line_num);

    running = 1;
    int64_t timeout_ns = 500000000LL; // 0.5s;

    while (running) {
        int ret = gpiod_line_request_wait_edge_events(request, timeout_ns);
        if (ret > 0) {
            int num_events = gpiod_line_request_read_edge_events(request, event_buf, 16);
            for (int i = 0; i < num_events; i++) {
                struct gpiod_edge_event *ev = gpiod_edge_event_buffer_get_event(event_buf, i);
                enum gpiod_edge_event_type ev_type = gpiod_edge_event_get_event_type(ev);
                uint64_t ts_ns = gpiod_edge_event_get_timestamp_ns(ev);

                uint64_t sec = ts_ns / 1000000000ULL;
                uint64_t nsec = ts_ns % 1000000000ULL;

                if (ev_type == GPIOD_EDGE_EVENT_RISING_EDGE) {
                    printf("line%u rising edge triggered, timestamp:%" PRIu64 ".%09" PRIu64 "\r\n", line_num, sec, nsec);
                } else if (ev_type == GPIOD_EDGE_EVENT_FALLING_EDGE) {
                    printf("line%u falling edge triggered, timestamp:%" PRIu64 ".%09" PRIu64 "\r\n", line_num, sec, nsec);
                }
            }
        }
    }

    pthread_join(thread, NULL);
    gpiod_line_request_release(request);
    reset_terminal_mode();

cleanup:
    if (event_buf) gpiod_edge_event_buffer_free(event_buf);
    if (settings) gpiod_line_settings_free(settings);
    if (line_cfg) gpiod_line_config_free(line_cfg);
    if (req_cfg) gpiod_request_config_free(req_cfg);
}

void gpio_test(void)
{
    int cmd;

    (void)!system("clear");

    list_gpio_chips();

    _print_gpio_cmd();

    do {
        printf("\n>> CMD ?\n");
        cmd = sgetche();
        printf("\n");

        switch (cmd) {
        case 'a':
        case 'A':
            gpio_chip_open();
            break;
        case 'b':
        case 'B':
            gpio_chip_close();
            break;
        case 'c':
        case 'C':
            get_chip_lines();
            break;
        case 'd':
        case 'D':
            gpio_chip_set_output();
            break;
        case 'e':
        case 'E':
            gpio_chip_get_input();
            break;
        case 'f':
        case 'F':
            gpio_chip_wait_input_event();
            break;
        case '?':
            _print_gpio_cmd();
            break;
        }

    } while (cmd != 'q' && cmd != 'Q');
}

